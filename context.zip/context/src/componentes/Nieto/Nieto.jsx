import React from 'react';
import { useContext } from 'react';
import { Contexto } from '../../context/context';

const Nieto = () => {
    const herencia = useContext(Contexto);

  return (
    <div>
        <p>Mi super herencia es de : {herencia.efectivo} </p>
        <p>Vendi estos departamentos: {herencia.propiedades} </p>
        <p>Me sobra la nafta, tengo: {herencia.nafta} </p>
    </div>
  )
}

export default Nieto






//UTILIZANDO EL CONSUMER: 
/*
import React from 'react'
import { Contexto } from '../../context/context';

const Nieto = () => {
    return (
        <Contexto.Consumer>
            {
                (herencia) => (
                    <div>
                        <p>Herencia: {herencia.efectivo} </p>
                        <p>Nafta: {herencia.nafta} </p>
                    </div>
                )
            }
        </Contexto.Consumer>
    )
}
//Usamos una función de renderizado para poder tomar los datos de la herencia. 
export default Nieto

*/




/////////////////////////////////////////////////////////////////////
//UTILIZANDO PROPS. 

/*
import React from 'react'

const Nieto = ({herencia}) => {
  return (
    <div>
        <p>Mi herencia es de: {herencia.efectivo} </p>
        <p>Tengo estos vehiculos: {herencia.vehiculos} </p>
        <p>Hago fiestas en estas casas: {herencia.propiedades} </p>
        <p>Desperdicio toda esta nafta: {herencia.nafta} </p>
    </div>
  )
}

export default Nieto

*/