import React from 'react'

/* CLASE 6: CONTEXT

Hasta este momento estuvimos trabajando con datos con las siguientes herramientas: 

- El Estado. 
- Las props. 

EJEMPLO DE COMO VENIAMOS TRABAJANDO CON LAS PROPS 

//Esta situación se conoce como "prop drilling". 

CONTEXT: 

¿Que es el context?
El contexto es una herramienta que me permite crear un estado global, un objeto que almecana información importante para la aplicación y que esta disponible desde cualquier componente. 

Tiene 3 partes: 

- El contexto en si. 
- El proveedor de contexto, es un componente que envuelve a toda la app habilitandola para que reciba datos. 
- El consumidor de contexto, es un componente que accede a esos datos globales. 

*/

import Abuelo from './componentes/Abuelo/Abuelo';
import { Contexto } from './context/context';


const App = () => {

  const herencia = {
    efectivo: 1000000,
    propiedades: 6,
    vehiculos: 10,
    nafta: 1000
  };

  return (
    <div>
      <Contexto.Provider value={herencia}>
        <Abuelo  />
      </ Contexto.Provider>
    </div>
  )
}

export default App