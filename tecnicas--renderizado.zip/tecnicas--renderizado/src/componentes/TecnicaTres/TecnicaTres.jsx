import React from 'react'

//3) Operador Ternario: 

const TecnicaTres = ({booleano}) => {
  return (
    <div>
        {
            booleano ? <h3>Acceso Permitido</h3> : <h3>Acceso Denegado! Vete Ladron Malvado! </h3>
        }

    </div>
  )
}

export default TecnicaTres